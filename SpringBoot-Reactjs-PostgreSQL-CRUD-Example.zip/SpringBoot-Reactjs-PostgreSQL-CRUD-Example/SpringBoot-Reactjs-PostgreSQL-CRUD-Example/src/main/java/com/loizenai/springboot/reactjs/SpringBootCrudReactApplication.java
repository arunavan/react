package com.loizenai.springboot.reactjs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudReactApplication.class, args);
	}
}
