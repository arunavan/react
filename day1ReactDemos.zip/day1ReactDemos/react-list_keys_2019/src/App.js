import React, { Component } from 'react';

const data = [
  {id: 'a', name: 'Devin'},
  {id: 'b', name: 'Gabe' },
  {id: 'c', name: 'Kim'},
];
const names = ['hi','hello','how','are','you'];
var listItems =null;
export default class App extends Component {

  constructor(props){
    
    super(props);
//     listItems = names.map((name,index) =>  <li>{index}, {name}</li>);
//{data.map(item => <div key={item.id}>{item.name}</div>)}
  listItems =data.map(item => <div> {item.id}-{item.name}</div>);
  }
  render() {
    return (
      
      <div>
        <h2>Welcome, {listItems}</h2>
        <br/>
      </div>
    );
  }
}

