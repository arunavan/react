
function  Header() {
    //JSX
    return (
      <div className="App">
        <h1>  Capgemini - FSD React 2021 batch1 </h1>
      </div>
    );
  }
  
  export default Header;